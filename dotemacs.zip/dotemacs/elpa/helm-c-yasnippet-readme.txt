Actions: Insert snippet, Open snippet file, Open snippet file other window
C-z: execute-persistent-action
