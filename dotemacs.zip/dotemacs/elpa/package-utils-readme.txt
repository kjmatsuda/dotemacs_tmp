This library provides extensions for package.el
