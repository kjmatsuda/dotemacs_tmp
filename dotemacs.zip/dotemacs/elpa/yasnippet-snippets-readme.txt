Official snippet collection for the yasnippet package.
