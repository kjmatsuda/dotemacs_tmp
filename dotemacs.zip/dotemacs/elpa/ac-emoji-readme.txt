auto-complete source of Emoji. It is useful for writing markdown or
commit message which are uploaded to github.com
