 Usage:
   (cdb-init "foo.cdb") -> nil
   (cdb-get "foo.cdb" "abc") -> "123"
   (cdb-keys "foo.cdb") -> ("abc" ...)
   (cdb-uninit "foo.cdb") -> nil
