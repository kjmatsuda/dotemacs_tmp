It is necessary to auto-complete.el Configurations.
heavily borrowed from dabbrev.el and skk-kakutei-extra.el.
Original Author is lugecy.  Thanks!!
<https://github.com/lugecy/dot-emacs/blob/master/local-elisp/ac-skk.el>

Installation:
=============================================

Put the ac-skk.el to your
load-path.
Add to init file :
(require 'ac-ja.el)
