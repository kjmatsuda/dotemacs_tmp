This extension provides logging framework for elisp.
