
A major mode for plantuml, see: http://plantuml.sourceforge.net/
Plantuml is an open-source tool in java that allows to quickly write :
    - sequence diagram,
    - use case diagram,
    - class diagram,
    - activity diagram,
    - component diagram,
    - state diagram
    - object diagram
