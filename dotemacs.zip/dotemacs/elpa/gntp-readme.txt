This package implements the Growl Notification Protocol GNTP
described at http://www.growlforwindows.com/gfw/help/gntp.aspx
It is incomplete as it only lets you send but not receive
notifications.
