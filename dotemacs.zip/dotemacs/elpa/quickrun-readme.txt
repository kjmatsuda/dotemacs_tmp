quickrun.el executes editing buffer. quickrun.el selects commands to execute
buffer automatically. Please see https://github.com/syohex/emacs-quickrun
for more information.

This package respects `quickrun.vim' developed by thinca
  - https://github.com/thinca/vim-quickrun

To use this package, add these lines to your .emacs file:
    (require 'quickrun)

And you call 'M-x quickrun'.
