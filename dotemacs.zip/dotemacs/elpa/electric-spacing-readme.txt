Smart Operator mode is a minor mode which automatically inserts
surrounding spaces around operator symbols.  For example, `='
becomes ` = ', `+=' becomes ` += '.  This is most handy for writing
C-style source code.

Type `M-x electric-spacing-mode' to toggle this minor mode.

Acknowledgements

Nikolaj Schumacher <n_schumacher@web.de>, for suggesting
reimplementing as a minor mode and providing an initial patch for
that.
