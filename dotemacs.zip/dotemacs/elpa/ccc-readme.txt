Buffer local frame parameters
--- cursor, foreground, background
--- TODO: support other frame parameters
          should use uni prefix for functions and variables?
