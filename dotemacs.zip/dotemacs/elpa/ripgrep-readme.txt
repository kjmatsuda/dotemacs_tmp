Emacs front-end for ripgrep, a command line search tool

Installation:

ripgrep.el is available on the two major community maintained repositories
Melpa stable (https://stable.melpa.org), and Melpa (https://melpa.org)

(add-to-list 'package-archives
             '("melpa" . "https://melpa.org/packages/") t)

M-x package-install ripgrep
