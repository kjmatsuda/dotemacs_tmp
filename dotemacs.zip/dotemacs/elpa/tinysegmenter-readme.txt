emacs lisp Version by lugecy (lugecy@gmail.com)

Installation:
=============================================

Put the tinysegmenter.el to your
load-path.
Add to init file :
(require 'tinysegmenter)
