This package allows you to undo/redo point and window-start.
It is like w3m's UNDO/REDO commands.
