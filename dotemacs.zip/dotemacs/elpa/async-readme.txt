Adds the ability to call asynchronous functions and process with ease.  See
the documentation for `async-start' and `async-start-process'.

