Org-pomodoro introduces an easy way to clock time in org-mode with
the pomodoro technique.  You can clock into tasks with starting a
pomodoro time automatically.  Each finished pomodoro is followed by
a break timer.  If you completed 4 pomodoros in a row the break is
longer that the shorter break between each pomodoro.

For a full explanation of the pomodoro technique, have a look at:
  http://www.pomodorotechnique.com
