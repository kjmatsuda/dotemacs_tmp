A modern list api for Emacs.

See documentation on https://github.com/magnars/dash.el#functions

**Please note** The lexical binding in this file is not utilised at the
moment. We will take full advantage of lexical binding in an upcoming 3.0
release of Dash. In the meantime, we've added the pragma to avoid a bug that
you can read more about in https://github.com/magnars/dash.el/issues/130.
