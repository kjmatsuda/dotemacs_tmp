NEW! You can now click on the rainbow (or the empty space)
to scroll your buffer!

NEW! You can now customize the minimum window width
below which the nyan-mode will be disabled, so that more important
information can be shown in the modeline.

To activate, just load and put `(nyan-mode 1)' in your init file.

Contributions and feature requests welcome!

Inspired by (and in few places copied from) sml-modeline.el written by Lennart Borgman.
See: http://bazaar.launchpad.net/~nxhtml/nxhtml/main/annotate/head%3A/util/sml-modeline.el
