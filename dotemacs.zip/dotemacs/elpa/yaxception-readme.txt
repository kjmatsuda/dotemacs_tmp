This extension provides framework about exception for elisp.
The framework features are the following.
- try/catch/finally coding style like Java
- custom error object
- stacktrace like Java
