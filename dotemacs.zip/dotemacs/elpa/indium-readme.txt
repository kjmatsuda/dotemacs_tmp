Indium connects to a browser tab or nodejs process and provides many features
for JavaScript development, including a REPL (with auto completion) & object
inspection, an inspector, with history and navigation, and even a stepping
Debugger, similar to `edebug`, or `cider`.
