sdic をwindows 7 にインストールする際に作成
辞書ファイルを置く
